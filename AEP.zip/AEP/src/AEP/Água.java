package AEP;

public class �gua {
	private double VolumeDaAgua;
	private double PHDaAguaMinimo;
	private double PHDaAguaMaximo;
	private double TurbidadeDaAgua;
	private double SalinidadeDaAguaM�ximo;
	private double OxygenioDaAgua;
	private double TemperaturaDaAguaMinimo;
	private double TemperaturaDaAguaMaximo;
	
	
	
	public �gua (double SalinidadeDaAguaM�ximo, double VolumeDaAgua, double PHDaAguaMinimo, double PHDaAguaMaximo, double TurbidadeDaAgua, double OxygenioDaAgua, double TemperaturaDaAguaMinimo, double TemperaturaDaAguaMaximo ) {
		this.VolumeDaAgua = VolumeDaAgua;
		this.PHDaAguaMinimo = PHDaAguaMinimo;
		this.PHDaAguaMaximo = PHDaAguaMaximo;
		this.TurbidadeDaAgua = TurbidadeDaAgua;
		this.SalinidadeDaAguaM�ximo = SalinidadeDaAguaM�ximo;
		this.OxygenioDaAgua = OxygenioDaAgua;
		this.OxygenioDaAgua = OxygenioDaAgua;
		this.TemperaturaDaAguaMinimo = TemperaturaDaAguaMinimo;
		this.TemperaturaDaAguaMaximo = TemperaturaDaAguaMaximo;
	}



	@Override
	public String toString() {
		return "�gua [VolumeDaAgua=" + VolumeDaAgua + ", PHDaAguaMinimo=" + PHDaAguaMinimo + ", PHDaAguaMaximo="
				+ PHDaAguaMaximo + ", TurbidadeDaAgua=" + TurbidadeDaAgua + ", SalinidadeDaAguaM�ximo="
				+ SalinidadeDaAguaM�ximo + ", OxygenioDaAgua=" + OxygenioDaAgua + ", TemperaturaDaAguaMinimo="
				+ TemperaturaDaAguaMinimo + ", TemperaturaDaAguaMaximo=" + TemperaturaDaAguaMaximo + "]";
	}
	
	
}
	

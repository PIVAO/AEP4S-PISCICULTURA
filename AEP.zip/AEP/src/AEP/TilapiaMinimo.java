package AEP;

public class TilapiaMinimo {

		private double TilapiaVolumeDaAgua; // 2 peixes por metro quadrado
		private double TilapiaPHDaAguaMinimo = 6; // 6
		private double TilapiaPHDaAguaMaximo = 9; // 8,5
		private double TilapiaTurbidadeDaAgua;
		private double TilapiaSalinidadeDaAguaM�ximo = 15; // 15ppt
		private double TilapiaOxygenioDaAgua;
		private double TilapiaTemperaturaDaAguaMinimo = 27; //27 �C
		private double TilapiaTemperaturaDaAguaMaximo = 32; //32 �C
		
		
		
		
		//TemperaturaDaAgua =; // entre 27 a 32�C
		
		public TilapiaMinimo ( double TilapiaSalinidadeDaAguaM�ximo, double TilapiaVolumeDaAgua, double TilapiaPHDaAguaMinimo, double TilapiaPHDaAguaMaximo, double TilapiaTurbidadeDaAgua, double TilapiaOxygenioDaAgua, double TilapiaTemperaturaDaAguaMinimo, double TilapiaTemperaturaDaAguaMaximo ) {
			this.TilapiaVolumeDaAgua = TilapiaVolumeDaAgua;
			this.TilapiaPHDaAguaMinimo = TilapiaPHDaAguaMinimo;
			this.TilapiaPHDaAguaMaximo = TilapiaPHDaAguaMaximo;
			this.TilapiaTurbidadeDaAgua = TilapiaTurbidadeDaAgua;
			this.TilapiaSalinidadeDaAguaM�ximo = TilapiaSalinidadeDaAguaM�ximo;
			this.TilapiaOxygenioDaAgua = TilapiaOxygenioDaAgua;
			this.TilapiaOxygenioDaAgua = TilapiaOxygenioDaAgua;
			this.TilapiaTemperaturaDaAguaMinimo = TilapiaTemperaturaDaAguaMinimo;
			this.TilapiaTemperaturaDaAguaMaximo = TilapiaTemperaturaDaAguaMaximo;
			
		}
			
			//if ( TilapiaSalinidadeDaAguaM�ximo == null || TilapiaSalinidadeDaAguaM�ximo.length() == 0,  TilapiaVolumeDaAgua == null, TilapiaPHDaAguaMinimo == null,  TilapiaPHDaAguaMaximo == null,  TilapiaTurbidadeDaAgua == null,  TilapiaOxygenioDaAgua == null,  TilapiaTemperaturaDaAguaMinimo == null, TilapiaTemperaturaDaAguaMaximo == null ) {
			//	throw new RuntimeException(" FAVOR PREENCHER TODOS OS CAMPOS ");
			//}

		
			


		@Override
		public String toString() {
			return "TilapiaMinimo [TilapiaVolumeDaAgua=" + TilapiaVolumeDaAgua + ", TilapiaPHDaAguaMinimo="
					+ TilapiaPHDaAguaMinimo + ", TilapiaPHDaAguaMaximo=" + TilapiaPHDaAguaMaximo
					+ ", TilapiaTurbidadeDaAgua=" + TilapiaTurbidadeDaAgua + ", TilapiaSalinidadeDaAguaM�ximo="
					+ TilapiaSalinidadeDaAguaM�ximo + ", TilapiaOxygenioDaAgua=" + TilapiaOxygenioDaAgua
					+ ", TilapiaTemperaturaDaAguaMinimo=" + TilapiaTemperaturaDaAguaMinimo
					+ ", TilapiaTemperaturaDaAguaMaximo=" + TilapiaTemperaturaDaAguaMaximo + "]";
		}
	
		
		
	}

	

package AEP;

public class Tanque {
	double AreaDoTanque;
	
	public Tanque (double AreaDoTanque) {
		this.AreaDoTanque = AreaDoTanque;
		
		
	}

	@Override
	public String toString() {
		return "Tanque [AreaDoTanque=" + AreaDoTanque + "]";
	}

}
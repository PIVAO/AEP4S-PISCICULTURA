package AEP;

public class App {
	private static final String TilapiaVolumeDaAgua = null;

	public static void main(String[] args ) {
		
		  Tanque tanque01 = new Tanque(20 );
		 // System.out.println(tanque01.AreaDoTanque);
		  
		  TilapiaMinimo Volumedaguadopeixe = new TilapiaMinimo(50, 77, 43, 30, 10, 12, 12, 15);
		  System.out.println("Os requisitos m�nimos de sobrevivencia das til�pias s�o : " + Volumedaguadopeixe);
		  
	
	}
}

